<div class="row">
    <div class="col-md-12">
        <div class="card-box" align="center">
          <h3>Sales Prediction for Nor Idaman Collection by Using Naive Bayes
          </h3>
        </div>
    </div>
</div>
