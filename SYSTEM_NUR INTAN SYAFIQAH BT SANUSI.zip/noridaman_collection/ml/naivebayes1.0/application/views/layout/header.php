<!-- Navigation Bar-->
<!-- <header id="topnav"> -->
    <!-- Topbar Start -->
    <!-- <div> -->
    <header class="navbar navbar-dark sticky-top flex-md-nowrap p-2 shadow" style="background-color:black; color:#EDBB99 ">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-4" href="index.php">Nor Idaman Collection</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
    <div class="navbar-nav">
        <div class="nav-item text-nowrap">
        <?php if(isset($_SESSION['admin_logged_in'])) { ?>
        <a class="nav-link px-3" href="logout.php?logout=1">Sign out</a>
        <?php } ?>
        </div>
    </div>
    </header> 
        

            <div class="clearfix"></div>
        </div>
    </div>
    <!-- end Topbar -->
    <?php $this->load->view("layout/menu",isset($navbar)?$navbar:array()); ?>
    <!-- end navbar-custom -->
</header>
<!-- End Navigation Bar-->
