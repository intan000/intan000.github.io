<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
               <b><?=isset($copyright)?$copyright:''?></b>
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="<?=isset($aboutus)?$aboutus:''?>">About Us</a>
                    <a href="<?=isset($help)?$help:''?>">Help</a>
                    <a href="<?=isset($contactus)?$contactus:''?>">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>
