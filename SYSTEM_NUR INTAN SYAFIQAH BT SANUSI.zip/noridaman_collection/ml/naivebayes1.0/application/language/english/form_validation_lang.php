<?php
$lang['form_validation_edit_unique']= 'The {field} field must contain a unique value.';
?>
