<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse" style="background-color: #ABB2B9; color:black">
      <div class="position-sticky pt-3">
         <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link active" style="color:black" aria-current="page" href="index.php">
              <span data-feather="home"></span>
              Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" style="color:black" aria-current="page" href="shopAdmin.php">
              <span data-feather="home"></span>
              Shop
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" style="color:black" href="index.php">
              <span data-feather="file"></span>
              Purchase List
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:black" href="products.php">
              <span data-feather="shopping-cart"></span>
              Products
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:black" href="add_product.php">
              <span data-feather="users"></span>
              Add New Product
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:black" href="../ml/naivebayes1.0">
              <span data-feather="layers"></span>
              Make Predictions
            </a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" style="color:black" href="predictSales.php">
              <span data-feather="layers"></span>
              Performance
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:black" href="prediction.php">
              <span data-feather="layers"></span>
              Predictions
            </a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link" style="color:black" href="promotion.php">
              <span data-feather="layers"></span>
              Promotion
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:black" href="discount.php">
              <span data-feather="layers"></span>
              Discount
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:black" href="account.php">
              <span data-feather="bar-chart-2"></span>
              Account
            </a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" style="color:black" href="help.html">
              <span data-feather="layers"></span>
              Help
            </a>
          </li> -->
        </ul>

     
      </div>
    </nav>


 