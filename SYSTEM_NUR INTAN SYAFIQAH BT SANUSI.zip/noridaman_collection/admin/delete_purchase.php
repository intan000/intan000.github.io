<?php 

session_start();
 
  include('../server/connection.php');

?>


<?php 
   
   if(!isset($_SESSION['admin_logged_in'])){
         header('location: login.php');
         exit();

   }


   if(isset($_GET['purchase_id'])){
       $purchase_id = $_GET['purchase_id'];
        $stmt = $conn->prepare("DELETE FROM purchase WHERE purchase_id=?");
        $stmt->bind_param('i',$purchase_id);

        if($stmt->execute()){

          header('location: index.php?deleted_successfully=Product has been deleted successfully');

        }else{
            header('location: index.php?deleted_failure=Could not delete product');
        }
   
   }

?>
