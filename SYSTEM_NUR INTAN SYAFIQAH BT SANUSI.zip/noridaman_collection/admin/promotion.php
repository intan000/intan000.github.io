<?php include('header.php'); ?>

<?php 
   
    if(!isset($_SESSION['admin_logged_in'])){
          header('location: login.php');
          exit();

    }

?>
          

<div class="container-fluid">
  <div class="row" style="min-height: 1000px">
   


     <?php include('sidemenu.php'); ?>





    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <br>
      <br>
      <!-- <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
       
      </div> -->
<!--        
      <center>
      <h3 class="mb-4"> Output of the dataset </h3>
      <img src ="../imgs/output_dataset.jpg"> -->

<div class="container">
  <div class="row">
    <div class="col-12">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">COMBINED PRODUCT</th>
            <th scope="col">PRODUCT</th>
            <th scope="col">COMBINE PRODUCT</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td></td>
            <td><b>0% Low Sales</b><br>BAJU KURUNG BIASA</th>
          
            <td><b>0.0048962637741047% High Sales</b> <br>BAJU KURUNG MODERN</td>
          </tr>
        
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-12">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">CRITERIA</th>
            <th scope="col">PURCHASE ON WEEKDAY</th>
            <th scope="col">PURCHASE ON WEEKEND</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td></td>
            <td>NO</th>
            <td>YES</td>
          </tr>
        
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-12">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">COMBO PRICE</th>
            <th scope="col">DISCOUNT 10%</th>
            <th scope="col">DISCOUNT 30%</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td></td>
            <td>Actual Combo Price <br> RM300</th>
            <td>Actual Combo Price <br> RM350 </td>
          </tr>

          <tr>
            <td></td>
            <td>Discounted Price <br> RM270</th>
            <td>Discounted Price <br> RM210</td>
          </tr>
        
        </tbody>
      </table>
    </div>
  </div>
</div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

      <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>

      
  </body>
</html>
