<?php include('header.php'); ?>

<?php 
   
    if(!isset($_SESSION['admin_logged_in'])){
          header('location: login.php');
          exit();

    }

?>
          

          <!DOCTYPE html>
<html>
<head>
	<title>Probability Discount Example</title>
	<style>
		.container {
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			text-align: center;
		}
		.discount {
			color: green;
			font-weight: bold;
		}
	</style>
</head>
<body>
	<div class="container">
		<h1>Probability Discount </h1>
		<p>Enter a probability between 0 and 1:</p>
    <p>If you get 30% discount it is on weekday, if not it is on weekend</p>
		<input type="text" id="probability" placeholder="0.0" />
		<button onclick="applyDiscount()">Apply Discount</button>
		<p id="result"></p>
	</div>
	
	<script>
		function applyDiscount() {
			var probability = parseFloat(document.getElementById('probability').value);
			var discount = '';
			if (probability >= 0.6) {
				discount = '30%';
			} else if (probability >= 0.2) {
				discount = '10%';
			} else {
				discount = '0%';
			}
			document.getElementById('result').innerHTML = 'You get a <span class="discount">' + discount + '</span> discount!';
		}
	</script>
</body>
</html>
